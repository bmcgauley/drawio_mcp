#!/usr/bin/env node

/**
 * Draw.io Diagram Generator MCP Server
 * 
 * This MCP server generates draw.io/diagrams.net XML files programmatically.
 * It creates valid mxGraphModel XML that can be opened directly in draw.io.
 */

import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
  Tool,
} from "@modelcontextprotocol/sdk/types.js";
import { z } from "zod";
import * as pako from "pako";

// ============================================================================
// Types and Schemas
// ============================================================================

const DiagramTypeSchema = z.enum([
  "flowchart",
  "sequence",
  "class",
  "er",
  "network",
  "infrastructure",
  "custom"
]);

const ShapeTypeSchema = z.enum([
  "rectangle",
  "rounded",
  "ellipse",
  "rhombus",
  "hexagon",
  "cylinder",
  "cloud",
  "actor",
  "note",
  "swimlane"
]);

const ConnectorStyleSchema = z.enum([
  "straight",
  "orthogonal",
  "curved",
  "dashed",
  "dotted"
]);

// Input schemas
const CreateDiagramSchema = z.object({
  title: z.string().describe("Title/name for the diagram"),
  description: z.string().describe("Text description of what to diagram"),
  diagram_type: DiagramTypeSchema.describe("Type of diagram to create"),
  output_format: z.enum(["uncompressed", "compressed"]).default("uncompressed")
    .describe("Whether to compress the XML output"),
  page_width: z.number().default(1100).describe("Page width in pixels"),
  page_height: z.number().default(850).describe("Page height in pixels"),
});

const AddShapeSchema = z.object({
  xml: z.string().describe("Existing diagram XML to add shape to"),
  shape_type: ShapeTypeSchema.describe("Type of shape to add"),
  text: z.string().describe("Text content for the shape"),
  x: z.number().describe("X coordinate position"),
  y: z.number().describe("Y coordinate position"),
  width: z.number().describe("Width of the shape"),
  height: z.number().describe("Height of the shape"),
  fill_color: z.string().default("#ffffff").describe("Fill color (hex)"),
  stroke_color: z.string().default("#000000").describe("Stroke color (hex)"),
});

const AddConnectionSchema = z.object({
  xml: z.string().describe("Existing diagram XML to add connection to"),
  source_id: z.string().describe("ID of source shape"),
  target_id: z.string().describe("ID of target shape"),
  label: z.string().optional().describe("Optional label for the connection"),
  style: ConnectorStyleSchema.default("orthogonal").describe("Connection line style"),
  arrow_end: z.boolean().default(true).describe("Show arrow at end"),
  arrow_start: z.boolean().default(false).describe("Show arrow at start"),
});

const CreateFlowchartSchema = z.object({
  title: z.string().describe("Flowchart title"),
  steps: z.array(z.object({
    id: z.string().describe("Unique identifier for this step"),
    type: z.enum(["start", "end", "process", "decision", "input", "output"])
      .describe("Type of flowchart element"),
    text: z.string().describe("Text content for the element"),
    next: z.array(z.string()).optional().describe("IDs of next steps (for decision nodes, provide multiple)"),
    decision_labels: z.array(z.string()).optional().describe("Labels for decision branches (e.g., ['Yes', 'No'])"),
  })).describe("Ordered list of flowchart steps"),
  output_format: z.enum(["uncompressed", "compressed"]).default("uncompressed"),
});

// ============================================================================
// Draw.io XML Generation
// ============================================================================

class DrawioGenerator {
  private cellIdCounter = 2; // IDs 0 and 1 are reserved for root cells

  /**
   * Generates a unique cell ID
   */
  private generateId(): string {
    return `cell-${this.cellIdCounter++}`;
  }

  /**
   * Creates a basic mxGraphModel structure
   */
  createBaseModel(pageWidth = 1100, pageHeight = 850): string {
    return `<mxGraphModel dx="1394" dy="747" grid="1" gridSize="10" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="1" pageScale="1" pageWidth="${pageWidth}" pageHeight="${pageHeight}" math="0" shadow="0">
  <root>
    <mxCell id="0"/>
    <mxCell id="1" parent="0"/>
  </root>
</mxGraphModel>`;
  }

  /**
   * Wraps mxGraphModel in mxfile structure
   */
  wrapInMxFile(graphModel: string, title = "Diagram", compressed = false): string {
    const content = compressed ? this.compressXml(graphModel) : graphModel;
    const timestamp = new Date().toISOString();
    
    return `<?xml version="1.0" encoding="UTF-8"?>
<mxfile host="app.diagrams.net" modified="${timestamp}" agent="MCP Draw.io Generator" version="24.0.0" type="device">
  <diagram name="${this.escapeXml(title)}" id="diagram-1">
    ${content}
  </diagram>
</mxfile>`;
  }

  /**
   * Compresses XML using deflate (for draw.io compressed format)
   */
  private compressXml(xml: string): string {
    const compressed = pako.deflate(xml, { level: 9 });
    const base64 = Buffer.from(compressed).toString('base64');
    return base64;
  }

  /**
   * Escapes XML special characters
   */
  private escapeXml(text: string): string {
    return text
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&apos;');
  }

  /**
   * Adds a shape to existing diagram XML
   */
  addShape(
    xml: string,
    shapeType: string,
    text: string,
    x: number,
    y: number,
    width: number,
    height: number,
    fillColor: string,
    strokeColor: string
  ): string {
    const id = this.generateId();
    const style = this.getShapeStyle(shapeType, fillColor, strokeColor);
    
    const cellXml = `    <mxCell id="${id}" value="${this.escapeXml(text)}" style="${style}" vertex="1" parent="1">
      <mxGeometry x="${x}" y="${y}" width="${width}" height="${height}" as="geometry"/>
    </mxCell>`;

    // Insert before closing </root> tag
    return xml.replace('</root>', `${cellXml}\n  </root>`);
  }

  /**
   * Gets the style string for a shape type
   */
  private getShapeStyle(shapeType: string, fillColor: string, strokeColor: string): string {
    const baseStyle = `fillColor=${fillColor};strokeColor=${strokeColor};`;
    
    const shapeStyles: Record<string, string> = {
      rectangle: `${baseStyle}whiteSpace=wrap;html=1;`,
      rounded: `${baseStyle}rounded=1;whiteSpace=wrap;html=1;`,
      ellipse: `${baseStyle}ellipse;whiteSpace=wrap;html=1;`,
      rhombus: `${baseStyle}rhombus;whiteSpace=wrap;html=1;`,
      hexagon: `${baseStyle}shape=hexagon;perimeter=hexagonPerimeter2;whiteSpace=wrap;html=1;`,
      cylinder: `${baseStyle}shape=cylinder;whiteSpace=wrap;html=1;`,
      cloud: `${baseStyle}ellipse;shape=cloud;whiteSpace=wrap;html=1;`,
      actor: `${baseStyle}shape=umlActor;verticalLabelPosition=bottom;verticalAlign=top;html=1;`,
      note: `${baseStyle}shape=note;whiteSpace=wrap;html=1;size=20;`,
      swimlane: `${baseStyle}swimlane;whiteSpace=wrap;html=1;startSize=23;`,
    };
    
    return shapeStyles[shapeType] || shapeStyles.rectangle;
  }

  /**
   * Adds a connection between two shapes
   */
  addConnection(
    xml: string,
    sourceId: string,
    targetId: string,
    label: string | undefined,
    style: string,
    arrowEnd: boolean,
    arrowStart: boolean
  ): string {
    const id = this.generateId();
    const edgeStyle = this.getConnectionStyle(style, arrowEnd, arrowStart);
    const labelAttr = label ? ` value="${this.escapeXml(label)}"` : '';
    
    const cellXml = `    <mxCell id="${id}"${labelAttr} style="${edgeStyle}" edge="1" parent="1" source="${sourceId}" target="${targetId}">
      <mxGeometry relative="1" as="geometry"/>
    </mxCell>`;

    return xml.replace('</root>', `${cellXml}\n  </root>`);
  }

  /**
   * Gets the style string for a connection
   */
  private getConnectionStyle(style: string, arrowEnd: boolean, arrowStart: boolean): string {
    const edgeStyles: Record<string, string> = {
      straight: 'edgeStyle=none;',
      orthogonal: 'edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;',
      curved: 'edgeStyle=orthogonalEdgeStyle;rounded=1;orthogonalLoop=1;jettySize=auto;html=1;',
      dashed: 'edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;dashed=1;',
      dotted: 'edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;dashed=1;dashPattern=1 4;',
    };
    
    let baseStyle = edgeStyles[style] || edgeStyles.orthogonal;
    
    if (arrowEnd) {
      baseStyle += 'endArrow=classic;endFill=1;';
    } else {
      baseStyle += 'endArrow=none;';
    }
    
    if (arrowStart) {
      baseStyle += 'startArrow=classic;startFill=1;';
    }
    
    return baseStyle;
  }

  /**
   * Creates a complete flowchart from step definitions
   */
  createFlowchart(
    title: string,
    steps: Array<{
      id: string;
      type: string;
      text: string;
      next?: string[];
      decision_labels?: string[];
    }>,
    compressed = false
  ): string {
    let xml = this.createBaseModel();
    
    // Shape dimensions and positioning
    const startX = 100;
    const startY = 50;
    const verticalSpacing = 100;
    const horizontalSpacing = 200;
    
    // Map to store shape IDs
    const shapeIds: Record<string, string> = {};
    
    // Add shapes
    steps.forEach((step, index) => {
      const id = this.generateId();
      shapeIds[step.id] = id;
      
      const y = startY + index * verticalSpacing;
      let shapeType: string;
      let width: number;
      let height: number;
      let fillColor: string;
      
      switch (step.type) {
        case 'start':
        case 'end':
          shapeType = 'ellipse';
          width = 120;
          height = 60;
          fillColor = '#d5e8d4';
          break;
        case 'decision':
          shapeType = 'rhombus';
          width = 120;
          height = 80;
          fillColor = '#fff2cc';
          break;
        case 'input':
        case 'output':
          shapeType = 'rounded';
          width = 140;
          height = 60;
          fillColor = '#dae8fc';
          break;
        default: // process
          shapeType = 'rectangle';
          width = 140;
          height = 60;
          fillColor = '#ffffff';
      }
      
      xml = this.addShape(
        xml,
        shapeType,
        step.text,
        startX,
        y,
        width,
        height,
        fillColor,
        '#000000'
      );
    });
    
    // Add connections
    steps.forEach((step) => {
      if (step.next && step.next.length > 0) {
        const sourceId = shapeIds[step.id];
        
        step.next.forEach((nextId, branchIndex) => {
          const targetId = shapeIds[nextId];
          if (targetId) {
            const label = step.decision_labels?.[branchIndex];
            xml = this.addConnection(
              xml,
              sourceId,
              targetId,
              label,
              'orthogonal',
              true,
              false
            );
          }
        });
      }
    });
    
    return this.wrapInMxFile(xml, title, compressed);
  }

  /**
   * Extracts cell IDs from existing diagram XML for reference
   */
  extractCellIds(xml: string): string[] {
    const idMatches = xml.match(/id="([^"]+)"/g);
    if (!idMatches) return [];
    
    return idMatches
      .map(match => match.replace('id="', '').replace('"', ''))
      .filter(id => id !== '0' && id !== '1'); // Exclude root cells
  }
}

// ============================================================================
// MCP Server
// ============================================================================

const generator = new DrawioGenerator();

const server = new Server(
  {
    name: "drawio-diagram-generator",
    version: "1.0.0",
  },
  {
    capabilities: {
      tools: {},
    },
  }
);

/**
 * Tool definitions
 */
const tools: Tool[] = [
  {
    name: "create_diagram",
    description: `Create a new draw.io diagram from a text description. This tool generates a complete draw.io XML file 
that can be saved and opened directly in draw.io/diagrams.net. The AI will interpret your description and create 
appropriate shapes and connections.

Use cases:
- Creating system architecture diagrams
- Designing database schemas (ER diagrams)
- Mapping network topologies
- Visualizing workflows and processes
- Building UML class diagrams`,
    inputSchema: {
      type: "object",
      properties: {
        title: {
          type: "string",
          description: "Title/name for the diagram"
        },
        description: {
          type: "string",
          description: "Detailed text description of what to diagram. Be specific about components, relationships, and layout."
        },
        diagram_type: {
          type: "string",
          enum: ["flowchart", "sequence", "class", "er", "network", "infrastructure", "custom"],
          description: "Type of diagram to create"
        },
        output_format: {
          type: "string",
          enum: ["uncompressed", "compressed"],
          default: "uncompressed",
          description: "XML output format - uncompressed for readability, compressed for smaller files"
        },
        page_width: {
          type: "number",
          default: 1100,
          description: "Canvas width in pixels"
        },
        page_height: {
          type: "number",
          default: 850,
          description: "Canvas height in pixels"
        }
      },
      required: ["title", "description", "diagram_type"]
    }
  },
  {
    name: "create_flowchart",
    description: `Create a flowchart diagram from structured step definitions. This tool is optimized for creating 
flowcharts with proper shapes for different element types (start/end, process, decision, input/output).

Features:
- Automatic shape selection based on step type
- Smart vertical layout with proper spacing
- Support for decision branches with labels
- Color-coded shapes by type
- Automatic connection routing

Example use: Process workflows, algorithm visualization, business process mapping`,
    inputSchema: {
      type: "object",
      properties: {
        title: {
          type: "string",
          description: "Flowchart title"
        },
        steps: {
          type: "array",
          items: {
            type: "object",
            properties: {
              id: {
                type: "string",
                description: "Unique identifier for this step (e.g., 'start', 'check_auth', 'end')"
              },
              type: {
                type: "string",
                enum: ["start", "end", "process", "decision", "input", "output"],
                description: "Type of flowchart element"
              },
              text: {
                type: "string",
                description: "Text content for the element"
              },
              next: {
                type: "array",
                items: { type: "string" },
                description: "IDs of next steps. For decision nodes, provide multiple."
              },
              decision_labels: {
                type: "array",
                items: { type: "string" },
                description: "Labels for decision branches (e.g., ['Yes', 'No'])"
              }
            },
            required: ["id", "type", "text"]
          },
          description: "Ordered list of flowchart steps"
        },
        output_format: {
          type: "string",
          enum: ["uncompressed", "compressed"],
          default: "uncompressed"
        }
      },
      required: ["title", "steps"]
    }
  },
  {
    name: "add_shape",
    description: `Add a new shape to an existing draw.io diagram. This tool allows you to programmatically extend 
diagrams by adding individual shapes with specific positioning, styling, and content.

Shape types available:
- rectangle: Standard box for processes, components
- rounded: Rounded corners for softer appearance  
- ellipse: Circles/ovals for start/end points
- rhombus: Diamonds for decisions
- hexagon: Six-sided shapes
- cylinder: Database representations
- cloud: Cloud services/storage
- actor: UML actor figures
- note: Annotation notes
- swimlane: Lane containers for grouping

Returns the modified diagram XML with the new shape added.`,
    inputSchema: {
      type: "object",
      properties: {
        xml: {
          type: "string",
          description: "Existing diagram XML (from previous create_diagram or add_shape calls)"
        },
        shape_type: {
          type: "string",
          enum: ["rectangle", "rounded", "ellipse", "rhombus", "hexagon", "cylinder", "cloud", "actor", "note", "swimlane"],
          description: "Type of shape to add"
        },
        text: {
          type: "string",
          description: "Text content for the shape"
        },
        x: {
          type: "number",
          description: "X coordinate position (pixels from left)"
        },
        y: {
          type: "number",
          description: "Y coordinate position (pixels from top)"
        },
        width: {
          type: "number",
          description: "Width of the shape in pixels"
        },
        height: {
          type: "number",
          description: "Height of the shape in pixels"
        },
        fill_color: {
          type: "string",
          default: "#ffffff",
          description: "Fill color in hex format (e.g., '#ffffff', '#dae8fc')"
        },
        stroke_color: {
          type: "string",
          default: "#000000",
          description: "Border color in hex format"
        }
      },
      required: ["xml", "shape_type", "text", "x", "y", "width", "height"]
    }
  },
  {
    name: "add_connection",
    description: `Add a connection (edge/arrow) between two existing shapes in a diagram. Connections link shapes 
together to show relationships, flow, or data transfer.

Connection styles:
- straight: Direct line between shapes
- orthogonal: Right-angled lines (most common for flowcharts)
- curved: Smooth curved lines
- dashed: Dashed lines for optional/conditional relationships
- dotted: Dotted lines for weak associations

Arrow configuration:
- arrow_end: Shows direction of flow (most common)
- arrow_start: Bidirectional arrows
- No arrows: Simple connecting lines

Returns the modified diagram XML with the new connection added.`,
    inputSchema: {
      type: "object",
      properties: {
        xml: {
          type: "string",
          description: "Existing diagram XML"
        },
        source_id: {
          type: "string",
          description: "ID of source shape (get from add_shape return value or use extract_cell_ids)"
        },
        target_id: {
          type: "string",
          description: "ID of target shape"
        },
        label: {
          type: "string",
          description: "Optional label text for the connection"
        },
        style: {
          type: "string",
          enum: ["straight", "orthogonal", "curved", "dashed", "dotted"],
          default: "orthogonal",
          description: "Connection line style"
        },
        arrow_end: {
          type: "boolean",
          default: true,
          description: "Show arrow at the end (target)"
        },
        arrow_start: {
          type: "boolean",
          default: false,
          description: "Show arrow at the start (source)"
        }
      },
      required: ["xml", "source_id", "target_id"]
    }
  }
];

/**
 * List available tools
 */
server.setRequestHandler(ListToolsRequestSchema, async () => {
  return { tools };
});

/**
 * Handle tool execution
 */
server.setRequestHandler(CallToolRequestSchema, async (request) => {
  try {
    const { name, arguments: args } = request.params;

    switch (name) {
      case "create_diagram": {
        const parsed = CreateDiagramSchema.parse(args);
        
        // For now, create a basic structure - in a production system,
        // you'd use an LLM to interpret the description and create appropriate shapes
        const xml = generator.createBaseModel(parsed.page_width, parsed.page_height);
        const wrapped = generator.wrapInMxFile(
          xml,
          parsed.title,
          parsed.output_format === "compressed"
        );
        
        return {
          content: [
            {
              type: "text",
              text: `Created diagram "${parsed.title}". Save the XML below as a .drawio file and open in draw.io:\n\n${wrapped}`
            }
          ]
        };
      }

      case "create_flowchart": {
        const parsed = CreateFlowchartSchema.parse(args);
        const xml = generator.createFlowchart(
          parsed.title,
          parsed.steps,
          parsed.output_format === "compressed"
        );
        
        return {
          content: [
            {
              type: "text",
              text: `Created flowchart "${parsed.title}" with ${parsed.steps.length} steps. Save the XML below as a .drawio file:\n\n${xml}`
            }
          ]
        };
      }

      case "add_shape": {
        const parsed = AddShapeSchema.parse(args);
        const newXml = generator.addShape(
          parsed.xml,
          parsed.shape_type,
          parsed.text,
          parsed.x,
          parsed.y,
          parsed.width,
          parsed.height,
          parsed.fill_color,
          parsed.stroke_color
        );
        
        const cellIds = generator.extractCellIds(newXml);
        const newId = cellIds[cellIds.length - 1];
        
        return {
          content: [
            {
              type: "text",
              text: `Added ${parsed.shape_type} shape "${parsed.text}" with ID: ${newId}\n\nUpdated diagram XML:\n${newXml}`
            }
          ]
        };
      }

      case "add_connection": {
        const parsed = AddConnectionSchema.parse(args);
        const newXml = generator.addConnection(
          parsed.xml,
          parsed.source_id,
          parsed.target_id,
          parsed.label,
          parsed.style,
          parsed.arrow_end,
          parsed.arrow_start
        );
        
        return {
          content: [
            {
              type: "text",
              text: `Added connection from ${parsed.source_id} to ${parsed.target_id}\n\nUpdated diagram XML:\n${newXml}`
            }
          ]
        };
      }

      default:
        throw new Error(`Unknown tool: ${name}`);
    }
  } catch (error) {
    if (error instanceof z.ZodError) {
      throw new Error(
        `Invalid arguments: ${error.errors
          .map((e) => `${e.path.join(".")}: ${e.message}`)
          .join(", ")}`
      );
    }
    throw error;
  }
});

/**
 * Start the server
 */
async function main() {
  const transport = new StdioServerTransport();
  await server.connect(transport);
  
  // Server will run until the connection is closed
  console.error("Draw.io Diagram Generator MCP Server running on stdio");
}

main().catch((error) => {
  console.error("Fatal error:", error);
  process.exit(1);
});
